import { NextRequest, NextResponse } from 'next/server'
import { createClient, createAdminClient } from '@/lib/supabase/server'
import { fillQrKartWithPython } from '@/lib/qr-kart/fill-qr-kart'

export const runtime = 'nodejs'
export const maxDuration = 120

export async function GET(req: NextRequest) {
  const supabase = createClient()
  const admin    = createAdminClient()

  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Yetkisiz' }, { status: 401 })

  const { data: me } = await supabase.from('users').select('rol,firma_id').eq('id', user.id).single()
  if (!me) return NextResponse.json({ error: 'Kullanıcı bulunamadı' }, { status: 403 })

  const isSA = me.rol === 'super_admin' || me.rol === 'alt_super_admin'
  const isTA = me.rol === 'tenant_admin'
  if (!isSA && !isTA) return NextResponse.json({ error: 'Yetki yetersiz' }, { status: 403 })

  const url             = new URL(req.url)
  const firmaId         = url.searchParams.get('firma_id')
  const projeId         = url.searchParams.get('proje_id')
  const ustLokasyonId   = url.searchParams.get('ust_lokasyon_id')   // filtre
  const origin          = url.searchParams.get('origin') || 'https://app.qrsync.com'

  const effectiveFirmaId = isSA ? firmaId : me.firma_id
  if (!effectiveFirmaId) return NextResponse.json({ error: 'firma_id zorunlu' }, { status: 400 })
  if (isTA && firmaId && firmaId !== me.firma_id) return NextResponse.json({ error: 'Yetkisiz firma' }, { status: 403 })

  let lokQuery = admin
    .from('lokasyonlar')
    .select('id,tanim,qr_veri,parent_id,aktif')
    .eq('firma_id', effectiveFirmaId)
    .order('tanim')
  if (projeId) lokQuery = (lokQuery as any).eq('proje_id', projeId)

  const { data: tumLokasyonlar, error } = await lokQuery
  if (error) return NextResponse.json({ error: error.message }, { status: 500 })

  const idToTanim = new Map<string, string>()
  ;(tumLokasyonlar ?? []).forEach((l: any) => idToTanim.set(l.id, l.tanim))

  // Üst lokasyon seçildiyse sadece o lokasyonun tüm torunları
  function getAllDescendantIds(rootId: string): string[] {
    const result = [rootId]
    const children = (tumLokasyonlar ?? []).filter((l: any) => l.parent_id === rootId)
    for (const c of children) result.push(...getAllDescendantIds(c.id))
    return result
  }

  let lokasyonlar = (tumLokasyonlar ?? []).filter((l: any) => l.aktif && l.qr_veri)
  if (ustLokasyonId) {
    const altIds = new Set(getAllDescendantIds(ustLokasyonId))
    altIds.delete(ustLokasyonId) // üst lokasyonun kendisini dahil etme
    lokasyonlar = lokasyonlar.filter((l: any) => altIds.has(l.id))
  }
  if (!lokasyonlar.length) return NextResponse.json({ error: 'QR kodu olan aktif lokasyon bulunamadı' }, { status: 404 })

  // Minimal mod: şablon yok, Python'a '-' geçiyoruz
  const payload = {
    lokasyonlar: lokasyonlar.map((l: any) => ({
      id:     l.id,
      tanim:  l.tanim,
      qr_url: `${origin}/qr/${l.qr_veri}`,
    })),
    ayarlar: { minimal_boyut: 320 },
  }

  const zipBuffer = await fillQrKartWithPython(
    Buffer.alloc(0),   // boş buffer — minimal modda kullanılmıyor
    payload,
    '-',               // '-' = minimal mod tetikleyici
  )

  return new NextResponse(zipBuffer as unknown as BodyInit, {
    headers: {
      'content-type': 'application/zip',
      'content-disposition': `attachment; filename="qr-kodlar-${new Date().toISOString().slice(0,10)}.zip"`,
      'content-length': zipBuffer.byteLength.toString(),
    },
  })
}

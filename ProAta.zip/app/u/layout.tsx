import { redirect } from 'next/navigation'
import { createClient } from '@/lib/supabase/server'
import Sidebar from '@/components/layout/Sidebar'

export default async function ULayout({ children }: { children: React.ReactNode }) {
  const supabase = createClient()
  const { data: { user: authUser } } = await supabase.auth.getUser()
  if (!authUser) redirect('/login')
  const { data: user } = await supabase.from('users').select('*').eq('id', authUser.id).single()
  if (!user || user.rol !== 'tenant_user') redirect('/login')
  const { data: firma } = user.firma_id
    ? await supabase.from('firmalar').select('ticari_unvan,firma_adi,logo_url').eq('id', user.firma_id).single()
    : { data: null }
  return (
    <div style={{ display: 'flex', minHeight: '100vh', background: '#f7f9f7' }}>
      <Sidebar user={user} firma={firma} />
      <div style={{ marginLeft: 282, flex: 1, display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>
        {children}
      </div>
    </div>
  )
}
